package com.example.translucentmono;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.util.TypedValue;

public class MainActivity extends Activity {
    private final String[] labels = { "Airtel Alert", "Calculator", "Calendar", "Camera", "ChatGPT", "Chrome", "Clock", "Contacts", "Echo Music", "Files", "Gallery", "Gmail", "Google", "GPay", "Instagram", "Keep Notes", "Maps", "Messages", "Phone", "Play Store", "Recorder", "Settings", "Weather", "WhatsApp", "X", "YouTube", "Drive", "Essential Apps", "Gemini", "Glyph", "Play Games", "Google TV", "Meet", "Personal Safety", "Photos", "YouTube Music" };
    private final String[] iconNames = { "airtel_alert", "calculator", "calendar", "camera", "chatgpt", "chrome", "clock", "contacts", "echo_music", "files", "gallery", "gmail", "google", "gpay", "instagram", "keep_notes", "maps", "messages", "phone", "play_store", "recorder", "settings", "weather", "whatsapp", "x", "youtube", "drive", "essential_apps", "gemini", "glyph", "play_games", "google_tv", "meet", "personal_safety", "photos", "youtube_music" };
    private boolean dark;
    private LinearLayout page;
    private TextView title, subtitle, section, description, status;
    private Button themeButton, applyButton;
    private GridLayout grid;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        dark = getPreferences(MODE_PRIVATE).getBoolean("dark", false);
        buildUi();
        applyTheme();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(20), dp(20), dp(20));
        scroll.addView(page);
        setContentView(scroll);

        title = new TextView(this);
        title.setText("TRANSLUCENT MONO");
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setLetterSpacing(0.06f);
        page.addView(title);

        subtitle = new TextView(this);
        subtitle.setText("Light + Dark edition · frosted monochrome icons");
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(6);
        page.addView(subtitle, subLp);

        themeButton = new Button(this);
        themeButton.setAllCaps(false);
        themeButton.setOnClickListener(v -> {
            dark = !dark;
            getPreferences(MODE_PRIVATE).edit().putBoolean("dark", dark).apply();
            applyTheme();
        });
        LinearLayout.LayoutParams themeLp = new LinearLayout.LayoutParams(-1, dp(48));
        themeLp.topMargin = dp(20);
        page.addView(themeButton, themeLp);

        section = new TextView(this);
        section.setText("ICON PREVIEW");
        section.setTextSize(12);
        section.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        section.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams secLp = new LinearLayout.LayoutParams(-1, -2);
        secLp.topMargin = dp(22);
        secLp.bottomMargin = dp(12);
        page.addView(section, secLp);

        grid = new GridLayout(this);
        grid.setColumnCount(4);
        page.addView(grid);
        for (int i = 0; i < labels.length; i++) {
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(4), dp(8), dp(4), dp(8));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.columnSpec = GridLayout.spec(i % 4, 1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(4));
            item.setLayoutParams(lp);

            ImageView image = new ImageView(this);
            image.setTag(iconNames[i]);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(62), dp(62));
            image.setLayoutParams(ip);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            item.addView(image);

            TextView name = new TextView(this);
            name.setText(labels[i]);
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            name.setGravity(Gravity.CENTER);
            name.setPadding(0, dp(6), 0, 0);
            item.addView(name);
            grid.addView(item);
        }

        description = new TextView(this);
        description.setText("Soft translucent icon surfaces with crisp monochrome glyphs. Switch between Light and Dark previews above.");
        description.setTextSize(14);
        description.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(-1, -2);
        descLp.topMargin = dp(18);
        page.addView(description, descLp);

        applyButton = new Button(this);
        applyButton.setText("Check launcher compatibility");
        applyButton.setAllCaps(false);
        applyButton.setOnClickListener(v -> {
            Intent launchers = new Intent(Intent.ACTION_MAIN);
            launchers.addCategory(Intent.CATEGORY_HOME);
            startActivity(Intent.createChooser(launchers, "Choose your home app"));
        });
        LinearLayout.LayoutParams applyLp = new LinearLayout.LayoutParams(-1, dp(52));
        applyLp.topMargin = dp(20);
        page.addView(applyButton, applyLp);

        status = new TextView(this);
        status.setText("Third-party icon pack support depends on your launcher. Nothing Launcher may not apply external packs directly.");
        status.setTextSize(12);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(10);
        statusLp.bottomMargin = dp(18);
        page.addView(status, statusLp);
    }

    private void applyTheme() {
        int bg = dark ? Color.rgb(24, 28, 25) : Color.rgb(243, 245, 241);
        int fg = dark ? Color.rgb(242, 245, 241) : Color.rgb(22, 26, 23);
        int secondary = dark ? Color.rgb(177, 187, 178) : Color.rgb(104, 113, 106);
        int buttonBg = dark ? Color.rgb(238, 241, 236) : Color.rgb(37, 43, 38);
        int buttonFg = dark ? Color.rgb(27, 32, 28) : Color.WHITE;
        page.setBackgroundColor(bg);
        title.setTextColor(fg);
        subtitle.setTextColor(secondary);
        section.setTextColor(fg);
        description.setTextColor(secondary);
        status.setTextColor(secondary);
        themeButton.setText(dark ? "☀  Switch to Light Theme" : "☾  Switch to Dark Theme");
        styleButton(themeButton, buttonBg, buttonFg);
        applyButton.setTextColor(buttonFg);
        styleButton(applyButton, buttonBg, buttonFg);
        for (int i=0; i<grid.getChildCount(); i++) {
            LinearLayout item = (LinearLayout) grid.getChildAt(i);
            for (int j=0; j<item.getChildCount(); j++) {
                View child = item.getChildAt(j);
                if (child instanceof ImageView) {
                    String name = (String) child.getTag();
                    int id = getResources().getIdentifier("ic_" + name + (dark ? "_dark" : ""), "drawable", getPackageName());
                    ((ImageView) child).setImageResource(id);
                } else if (child instanceof TextView) {
                    ((TextView) child).setTextColor(dark ? Color.rgb(232,236,231) : Color.rgb(48,55,49));
                }
            }
        }
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
    }

    private void styleButton(Button button, int bg, int fg) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(bg);
        shape.setCornerRadius(dp(16));
        button.setBackground(shape);
        button.setTextColor(fg);
    }
    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
