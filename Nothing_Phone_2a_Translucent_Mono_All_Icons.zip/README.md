# Translucent Mono — Light + Dark icon pack starter

Updated with app icons corresponding to the screenshots from the Nothing Phone (2a) app drawer and disabled-app list. Includes 36 app tiles, each with light and dark translucent variants, plus a theme toggle in the preview app.

**Important:** this is Android source project, not a compiled APK. It must be built using Android Studio or the included GitHub Actions workflow. Launcher support varies; Nothing Launcher may not apply third-party icon packs directly. Package/activity mappings are best-effort and may need adjustment for the exact apps installed on your device.
